import sys
lista_e=[]
pila = []
lista_s =[]

lista_e = sys.argv[1]

if lista_e:
	print lista_e	
	for i in lista_e:
		if ord(i) > 47 and ord(i) < 58:
			lista_e.pop()
	print lista_e
else:
	print "Porfavor ingresa tu expresion"
	