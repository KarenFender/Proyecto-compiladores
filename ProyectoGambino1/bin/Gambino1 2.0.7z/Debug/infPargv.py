import sys
lpos = []
alfabeto=[]
pila = ['n']

expresion = sys.argv[1]

for i in expresion:
    if (ord(i)>=65 and ord(i)<=90) or (ord(i)>=97 and ord(i)<=122):
        lpos.append(i) 
	alfabeto.append(i)
    else:
        if pila == [] or pila[len(pila)-1] == "(" or i == "(":
            pila.append(i) 
        elif i == "+" or i == "*":
            if pila[len(pila)-1] == "+" or pila[len(pila)-1] == "*":
                lpos.append(i)
            else:
                pila.append(i)
        elif i == "-":
            #print "len(pila)"
            #print len(pila)

            while pila[len(pila)-1] == "+" or pila[len(pila)-1] == "*":
                lpos.append(pila.pop())
                #print len(pila)
            if pila[len(pila)-1] == "-":
                lpos.append(i)
            else:
                pila.append(i)
        elif i == "/":
            while pila[len(pila)-1] == "+" or pila[len(pila)-1] == "*" or pila[len(pila)-1] == "-":
                lpos.append(pila.pop())
            if pila[len(pila)-1] == "/":
                lpos.append(i)
            else:
                pila.append(i)
        else:
            while pila[len(pila)-1] != "(":
                lpos.append(pila.pop())
            pila.pop()

while len(pila) > 1:
    lpos.append(pila.pop())

#print "Notacion posfija \n"
print lpos

#archivo=open("postfija.txt","wb")
#archivo.write(str(lpos))
#archivo.close()
for j in range(len(alfabeto)-1, -1, -1):
    if alfabeto[j] in alfabeto[:j]:
	  #print lista_a
	  del(alfabeto[j])
     
#print "Alfabeto:"  
#print alfabeto	
